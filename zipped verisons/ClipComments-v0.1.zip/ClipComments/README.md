# Clip Comments

## v0.1 - Final
this is the readme for beta v0.1, currently the extension can read the data from netflix, genreate a hashtag and allow you to send tweets and read tweets with the corresponding hashtag. I plan to comment all my code at some point. Every tweet also includes a link to the @ClipComments twitter account which will be important in the future when comments are stoted on some sort of backend so they can be show on the extension itself

<br>
<hr>

## General Info
This is a Chrome Extension that will be able to identify what show/movei you are wathcing on netflix and show you what others are saying about the part you are currently watching. This is all done through twitter and uniuqe hashtages for each 15 second section of every video on netflix. These hashtags are automatically generated based on show title, season, episode and current time of the video. More to details follow